const help = (prefix) => { 
	return `                 
┏━━°❀❬ *BOT FOZZ* ❭❀°━━┓
┃
┣➥ *GC MIMIN X BOT:* https://chat.whatsapp.com/ESF23dPrrFZHuIcmCLjOz3
┣➥ *NOMER AUTHOR:* wa.me/628989931500
┣➥ *BOT AKTIF:* *JAM 09:00 - 00:00*
┃ *MAAF JIKA ADA FITUR YG EROR*
┣━━°❀ ❬ *BOT* ❭ ❀°━━━━━⊱
┃        *PERATURAN BOT*
┣➥ *NO TP/VC*
┣➥ *NO SPAM*
┣➥ *NO RUSUH*
┃ *NGELANGGAR AUTO BLOK*
┣━━°❀ ❬ *INFO BOT* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}info*
┣➥ *${prefix}donasi*
┣➥ *${prefix}owner*
┣➥ *${prefix}speed*
┣➥ *${prefix}report [lapor bug]*
┣➥ *${prefix}request [ubah bot]*
┃
┣━━°❀ ❬ *MEDIA* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}ocr*
┣➥ *${prefix}toimg*
┣➥ *${prefix}ytsearch*
┣➥ *${prefix}ytmp3*
┣➥ *${prefix}ytmp4*
┣➥ *${prefix}tiktok*
┣➥ *${prefix}tiktokstalk*
┣➥ *${prefix}fototiktok*
┣➥ *${prefix}igstalk*
┣➥ *${prefix}image*
┣➥ *${prefix}pinterest*
┣➥ *${prefix}tts*
┣➥ *${prefix}tes*
┣➥ *${prefix}tep*
┣➥ *${prefix}ttp*
┣➥ *${prefix}meme*
┣➥ *${prefix}ssweb*
┣➥ *${prefix}inu*
┣➥ *${prefix}elang*
┣➥ *${prefix}unta*
┣➥ *${prefix}anjing*
┣➥ *${prefix}babi*
┣➥ *${prefix}playstore*
┣➥ *${prefix}url2image*
┣➥ *${prefix}kbbi*
┣➥ *${prefix}imoji*
┣➥ *${prefix}wait*
┃
┣━━━━°❀❬ *CREATOR* ❭❀°━━━━⊱
┃
┣➥ *${prefix}sticker
┣➥ *${prefix}ocr
┣➥ *${prefix}thunder*
┣➥ *${prefix}tahta*
┣➥ *${prefix}glitch <teks|teks>*
┣➥ *${prefix}phlogo <teks|teks>*
┣➥ *${prefix}wolflogo <teks|teks>*
┣➥ *${prefix}wolflogo2 <teks|teks>*
┣➥ *${prefix}quotemaker <tx|wtrmk|tema>*
┣➥ *${prefix}galaxtext*
┣➥ *${prefix}textdark*
┣➥ *${prefix}textblue*
┣➥ *${prefix}lovemake*
┣➥ *${prefix}stiltext*
┣➥ *${prefix}ninjalogo*
┣➥ *${prefix}party*
┣➥ *${prefix}rtext*
┣➥ *${prefix}water*
┣➥ *${prefix}lionlogo <teks|teks>*
┣➥ *${prefix}textscreen*
┣➥ *${prefix}text3d*
┣➥ *${prefix}epep*
┣➥ *${prefix}marvelogo <teks|teks>*
┣➥ *${prefix}snow <teks|teks>*
┣➥ *${prefix}firetext*
┃
┣━━━°❀❬ *FUN&GAMES* ❭❀°━━━⊱
┃
┣➥ *${prefix}truth*
┣➥ *${prefix}dare*
┣➥ *${prefix}bucin*
┣➥ *${prefix}persengay*
┃
┣━━━━━°❀ ❬ *ANIME* ❭ ❀°━━━━━⊱
┃ *bot tidak kirim gambar=jaringan*
┃ *lelet*
┣➥ *${prefix}openanime*
┣➥ *${prefix}anime*
┣➥ *${prefix}nekonime*
┣➥ *${prefix}loli*
┣➥ *${prefix}loli2*
┣➥ *${prefix}waifu*
┣➥ *${prefix}waifu2*
┣➥ *${prefix}wibu*
┣➥ *${prefix}randomanime*
┣➥ *${prefix}pokemon*
┣➥ *${prefix}artinama*
┃
┣━━°❀❬ *INFO&EDUKASI* ❭❀°━━⊱
┃
┣➥ *${prefix}infogc*
┣➥ *${prefix}infogempa*
┣➥ *${prefix}infogithub*
┣➥ *${prefix}infocuaca*
┣➥ *${prefix}infonomor*
┣➥ *${prefix}infomobil*
┣➥ *${prefix}infomotor*
┣➥ *${prefix}grupinfo*
┣➥ *${prefix}lirik*
┣➥ *${prefix}quotes*
┣➥ *${prefix}cerpen*
┣➥ *${prefix}chord*
┣➥ *${prefix}wiki*
┣➥ *${prefix}brainly*
┣➥ *${prefix}resepmasakan*
┣➥ *${prefix}map*
┃
┣━━━━━°❀❬ *GRUP* ❭❀°━━━━━⊱
┃
┣➥ *${prefix}add*
┣➥ *${prefix}kick*
┣➥ *${prefix}promote*
┣➥ *${prefix}demote*
┣➥ *${prefix}setname*
┣➥ *${prefix}setdesc*
┣➥ *${prefix}welcome*
┣➥ *${prefix}nsfw*
┣➥ *${prefix}simih*
┣➥ *${prefix}grup [buka/tutup]*
┣➥ *${prefix}tagme*
┣➥ *${prefix}hidetag*
┣➥ *${prefix}tagall*
┣➥ *${prefix}otagall*
┣➥ *${prefix}fitnah*
┣➥ *${prefix}infogc*
┣➥ *${prefix}grupinfo*
┣➥ *${prefix}linkgrup*
┣➥ *${prefix}listadmins*
┣➥ *${prefix}openanime*
┣➥ *${prefix}edotense*
┃
┣━━━━━°❀❬ *NSFW* ❭❀°━━━━━⊱
┃
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}nsfwblowjob*
┣➥ *${prefix}nsfwneko*
┣➥ *${prefix}nsfwtrap*
┣➥ *${prefix}randomhentai*
┣➥ *${prefix}hentai*
┣➥ *${prefix}indohot*
┃
┣━━━━°❀❬ *KERANG* ❭❀°━━━━━⊱
┃
┣➥ *${prefix}apakah*
┣➥ *${prefix}kapankah*
┣➥ *${prefix}bisakah*
┣➥ *${prefix}rate*
┣➥ *${prefix}watak*
┣➥ *${prefix}hobby*
┃
┣━━━━━°❀❬ *OTHER* ❭❀°━━━━━⊱
┃
┣➥ *${prefix}blocklist*
┣➥ *${prefix}testime*
┣➥ *${prefix}hilih*
┣➥ *${prefix}say*
┣➥ *${prefix}delete*
┣➥ *${prefix}shorturl*
┃
┣━━━━°❀❬ *OWNER* ❭❀°━━━━━⊱
┃
┣➥ *${prefix}bc*
┣➥ *${prefix}ban*
┣➥ *${prefix}block*
┣➥ *${prefix}unblock*
┣➥ *${prefix}clearall*
┣➥ *${prefix}clone*
┣➥ *${prefix}getses*
┣➥ *${prefix}setpp*
┣➥ *${prefix}setpp*
┣➥ *${prefix}leave*
┃
┣━━━━━°❀❬ *TQTO* ❭❀°━━━━━⊱
┃
┣➥ *.XPTN*
┣➥ *.ALFA*
┣➥ *.ARUGAZ*
┣➥ *.MHANKBARBAR*
┣➥ *.IBNU NR*
┣➥ *.DLL*
┃
┃ *MAAF JIKA ADA FITUR YANG*
┃ *GAK BERFUNGSI*
┣━━━━━━━━━━━━━━━━━━━━
┃ *.POWERED BY BOT FROZZ*
┗━━━━━━━━━━━━━━━━━━━━`
}
exports.help = help
